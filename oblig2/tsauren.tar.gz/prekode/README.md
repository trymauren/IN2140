Leser superblokkfilen rekursivt, og lager structs for å representere inoder i loading_recursive(),
som kalles av load_inodes().
Alle tester fungerer, bortsett fra at det er en minnelekkasje når programmet kjører i load_example.
Finner ikke feilen.

For å kjøre programmet med full valgrind- sjekk:

$ bash run.sh

For å rydde:

$ bash clean.sh
